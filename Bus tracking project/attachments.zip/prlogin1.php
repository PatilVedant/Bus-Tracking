<?php


$id = $POST['id'];
$pswd =$POST['pswd'];
$con = mysql_connect("localhost", "root", "");
mysql_select_db("tracking",$con);
if (!$con) {
    die("Connection Failed: ".mysql_error());
}
//include "dbh1.php"
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php


$checksql = "SELECT * FROM parents WHERE id= '$id' AND pswd= '$pswd'";
$tempdata = mysql_query($checksql,$con);
$result = mysql_fetch_array($tempdata);

if ($result['id'] != $id AND $result['pswd'] != $pswd)
     {
       session_destroy();?><div class="main">
        <div class="login-box"><form class="form-box"><div class="account">Your ID Or Password Is Incorrect!</div><br>

        <a href="prlogin.php" class="reg">Go Back To Login Page!</a><?php
        exit();

        


    }
    else {

header ("Location: stloginp.php");


    }