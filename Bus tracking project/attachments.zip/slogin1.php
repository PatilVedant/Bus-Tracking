<?php
session_start();

$studid = $_SESSION['studid'];
$stname = $_SESSION['stname'];

include "dbh.php"
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php


$checksql = "SELECT * FROM category WHERE studid= '$studid'";
$tempdata = mysql_query($checksql,$con);
$result = mysql_fetch_array($tempdata);


if ($result['studid'] == $studid && $result['stname'] != $stname)
     {
      ?><div class="main">
        <div class="login-box"><form class="form-box"><div class="account">This Roll No Already Exist!</div><br>

        <a href="load.php" class="reg">Go Back To Student Information Page!</a><?php
        exit();
        
    }


 else {       

$sql = "SELECT * FROM category WHERE studid = '$studid' AND stname = '$stname'";

$myData = mysql_query($sql,$con);

echo "<center><table border=3>
<tr>
<th>Roll No</th>
<th>Student Name</th>
<th>Address</th>
<th>Internet Access</th>
<th>Mother Education</th>
<th>Father Education</th>
<th>Fathers Job</th>
<th>Travel Time</th>
<th>Study Time</th>
<th>Free Time</th>
<th>Extra Activities</th>
<th>Test 1</th>
<th>Test 2</th>
</tr>";


$record1 ;
while($record = mysql_fetch_array($myData)) {
echo "<tr>";
echo "<td>" . $record['studid'] . "</td>";

echo "<td>" . $record['stname'] . "</td>";

if($record['address']=="u" || $record['address']=="U") {echo "<td>Urban</td>"; }
    else {echo "<td>Rural</td>";}

if($record['internet']=="1") {echo "<td>Yes</td>"; }
    else {echo "<td>No</td>";}

if($record['medu']=="0") {echo "<td>Non Educated</td>"; }
    else if($record['medu']=="1") {echo "<td>Primary</td>"; }
    else if($record['medu']=="2") {echo "<td>4th Grade</td>"; }
    else if($record['medu']=="3") {echo "<td>5th-9th Grade</td>"; }
    else if($record['medu']=="4") {echo "<td>Secondary Education</td>"; }
    else if($record['medu']=="5") {echo "<td>Higher Education</td>"; }

if($record['fedu']=="0") {echo "<td>Non Educated</td>"; }
    else if($record['fedu']=="1") {echo "<td>Primary</td>"; }
    else if($record['fedu']=="2") {echo "<td>4th Grade</td>"; }
    else if($record['fedu']=="3") {echo "<td>5th-9th Grade</td>"; }
    else if($record['fedu']=="4") {echo "<td>Secondary Education</td>"; }
    else if($record['fedu']=="5") {echo "<td>Higher Education</td>"; }

    echo "<td>" . $record['fjob'] . "</td>";

if($record['traveltime']=="0") {echo "<td>15 Mins</td>"; }
    else if($record['traveltime']=="1") {echo "<td>15-3o Mins</td>"; }
    else if($record['traveltime']=="2") {echo "<td>30mins-1hr</td>"; }
    else if($record['traveltime']=="3") {echo "<td>1hr-1:30hr</td>"; }
    else if($record['traveltime']=="4") {echo "<td>1:30hr-2hr</td>"; }
    else if($record['traveltime']=="5") {echo "<td>more then 2hr</td>"; }

if($record['studytime']=="0") {echo "<td>15 Mins</td>"; }
    else if($record['studytime']=="1") {echo "<td>15-3o Mins</td>"; }
    else if($record['studytime']=="2") {echo "<td>30mins-1hr</td>"; }
    else if($record['studytime']=="3") {echo "<td>1hr-1:30hr</td>"; }
    else if($record['studytime']=="4") {echo "<td>1:30hr-2hr</td>"; }
    else if($record['studytime']=="5") {echo "<td>more then 2hr</td>"; }


if($record['freetime']=="0") {echo "<td>15 Mins</td>"; }
    else if($record['freetime']=="1") {echo "<td>15-3o Mins</td>"; }
    else if($record['freetime']=="2") {echo "<td>30mins-1hr</td>"; }
    else if($record['freetime']=="3") {echo "<td>1hr-1:30hr</td>"; }
    else if($record['freetime']=="4") {echo "<td>1:30hr-2hr</td>"; }
    else if($record['freetime']=="5") {echo "<td>more then 2hr</td>"; }


if($record['activity']=="1") {echo "<td>Yes</td>"; }
     else {echo "<td>No</td>";}

    echo "<td>" . $record['t1'] . " marks</td>";
    echo "<td>" . $record['t2'] . " marks</td>";

    echo "</tr>";

$record1 = $record;
}
echo "</table></center>";
}
?>
<div class="main">
  <div class="logout-box">
<form class="form-box1">
<a href="load.php" class="reg">Display Another Student Information?</a>

<?php
/////
//include "states.php"
//echo $record1['traveltime'];
//all if else statement

//tt 0 st 5

}

//////////////////////////////////////////////////////////////

?>


     
      
      </div>
    </form>

</body>

</html>