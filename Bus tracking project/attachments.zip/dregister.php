    <head>
     <link rel="stylesheet" type="text/css" href="style.css">
   
</head>

   <div class="main">
          <div class="login-box">
          <div class="info">Register</div>
        <form name="login" action="dregister1.php" method="post" class="form-box">


        <label class="account" for="id">User ID:</label>
        <input type="numeric" style=background-color:white name="id" class="inp" placeholder="ID Number" ><br>

        <label class="account" for="password">Password:</label>
        <input type="password" style=background-color:white name="pswd" class="inp" placeholder="*****"><br><br>
        
        <input type="submit" name="submit" value="REGISTER" class="sub-btn"><br><br><br>
