<?php

session_start();



?>

<!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Student Info Page</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <script>
     

        </script>
        </head>
        <body>
        
          
        <h1><center><u>WELCOME</u></center></h1>
          <div class="main">
          <div class="login-box">
       
        <form name="login" action="firebase.php" onsubmit="return validate()" method="post" class="form-box">

        
        
        <input type="submit" name="submit" value="LOCATE BUS" class="sub-btn"><br><br><br>

        <a href="vstud.php" class="sub-btn">VIEW STUDENT DETAILS</a><br><br><br><br>
       
        <a href="dregister.php" class="sub-btn">REGISTER NEW DRIVER                 </a><br><br><br><br>

        <a href="nav.php" class="sub-btn">LOGOUT</a>
        </form>


        </div>
        </div>
        </body>
        </html>