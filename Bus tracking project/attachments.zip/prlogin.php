<?php

session_start();
  
?>
<!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Login Page</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <script>
      

        </script>
        </head>
        <body>
        
        <h1><center><u>PARENT LOGIN</u></center></h1>
          <div class="main">
          <div class="login-box">
          <div class="info">Login into your account!</div>
        <form name="login" action="prlogin1.php" onsubmit="return validate()" method="post" class="form-box">

        <label class="account" for="id">User ID:</label>
        <input type="numeric" style=background-color:white name="id" class="inp" placeholder="ID" ><br>

        <label class="account" for="password">Password:</label>
        <input type="password" style=background-color:white name="pswd" class="inp" placeholder="*****"><br><br>

        
        
        <input type="submit" name="submit" value="LOGIN" class="sub-btn"><br><br><br>
        <a href="nav.php" class="sub-btn">BACK</a><br><br>






        </form>
        </div>
        </div>
        </body>
        </html>