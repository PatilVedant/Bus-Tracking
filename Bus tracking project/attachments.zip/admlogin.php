<?php
session_start();
$con = mysqli_connect("localhost", "root", "");
mysql_select_db("tracking",$con);
if (!$con) {
    die("Connection Failed: ".mysql_error());
}
//include "dbh1.php"
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php
$id = $_SESSION['id'];
$pswd =$_SESSION['pswd'];

$checksql = "SELECT * FROM adm WHERE id= '$id' AND pswd= '$pswd'";
$tempdata = mysql_query($checksql,$con);
$result = mysql_fetch_array($tempdata);

if ($result['id'] != $id AND $result['pswd'] != $pswd)
     {
       session_destroy();?><div class="main">
        <div class="login-box"><form class="form-box"><div class="account">Your ID Or Password Is Incorrect!</div><br>

        <a href="index.php" class="reg">Go Back To Login Page!</a><?php
        exit();

        


    }
    else {

header ("Location: stlogin.php");


    }