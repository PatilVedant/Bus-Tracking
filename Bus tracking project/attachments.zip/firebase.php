<!DOCTYPE html>
<html>
 <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
       
        <title>Student Info Page</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<style>
#map-canvas {
  height: 100%;
  width: 100%;
  margin: 0px;
  padding: 0px
}
       #map {
        height: 600px;
        width: 100%;
       }
       #icon{
       

       }
    </style>
        </head>
        <body>
          
          latitude:<input type="number" name="num1" id="lat1">

          longitude:<input type="number" name="num2" id="long1"><br>

<p id="demo"></p>
    <div id="map"></div>
<script src="https://www.gstatic.com/firebasejs/4.12.1/firebase.js"></script>

<script>
  // Initialize Firebase
  /////your firebase here

  var rootRef=firebase.database().ref().child('Cord');
    var rootRef2=firebase.database().ref().child('locationbycode/2');


   rootRef.on('value',function(snapshot){
        $('#lat1').val(snapshot.child('lat').val());
        
          $('#long1').val(snapshot.child('lon').val());
    });
 
    var queryString = "?para1=" + document.getElementById("lat1").value + "&para2=" + document.getElementById("long1").value;

queryString = queryString.substring(1);
var queries = queryString.split("&");

 var latitude=queries[0].substring(6);
 var longitude=queries[1].substring(6);                        
          var x=parseFloat(latitude);
        var y=parseFloat(longitude);

      
//latitude>=18.989804 || latitude<=18.992641 || longitude>=73.124874 || longitude<=73.127906
if (true) {


setTimeout(function initMap(){

 
    var queryString = "?para1=" + document.getElementById("lat").value + "&para2=" + document.getElementById("lon").value;

queryString = queryString.substring(1);
var queries = queryString.split("&");

 var latitude=queries[0].substring(6);
 var longitude=queries[1].substring(6);                        
          var x=parseFloat(latitude);
        var y=parseFloat(longitude);


         var directionsDisplay=new google.maps.DirectionsRenderer();
var  directionsService = new google.maps.DirectionsService();
var map;
  var myLatLng = {lat: x, lng: y};
  var sc=new google.maps.LatLng(18.989865,73.127789);
var ckt=new google.maps.LatLng(18.993013,73.124726);
            
            var myLatLng = {lat: x, lng: y};
            
            map = new google.maps.Map(document.getElementById('map'), {
              center: myLatLng,
         //      mapTypeId: google.maps.MapTypeId.SATELLITE,
              zoom: 6

            });
  directionsDisplay.setMap(map);
            var icon = {
    url: "bus.png", // url
    scaledSize: new google.maps.Size(40, 50), // scaled size
   
};
                    
            var marker = new google.maps.Marker({
              position: myLatLng,
               icon: icon,
               
              map: map,
             
         
              title: latitude + ', ' + longitude 
            });     
               calcRoute();
function calcRoute() {


var request={
    origin:sc,
    destination:ckt,
    travelMode:'DRIVING'
};

                directionsService.route(request, function (request, status) {
if(status== "OK")  {
    directionsDisplay.setDirections(request);
}              });
            }
          

    //do what you need here
}, 250);

}



else 
{
  alert("School Bus Route Deviated..!!");
window.location.replace("form.html");
}

var mapOptions = {
                    zoom: 12,
                    center: sc
                };

                                map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
              
             //  var marker = new google.maps.Marker({
      //   position: hattisar2,
       //  map: map,
    
      //  });


</script>
<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=">
    </script>
        </body>
        </html>