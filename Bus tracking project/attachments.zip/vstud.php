

<!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Student Info Page</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <script>
       

        </script>
        </head>
        <body>
        
        <h1><center><u>STUDENT INFORMATION</u></center></h1>
          <div class="main">
          <div class="login-box">
          <!--<div class="info">Login into your account!</div>-->
        <form name="login" action="login1.php" onsubmit="return validate()" method="post" class="form-box">

        <label class="account" for="roll no">Roll No:</label>
        <input type="numeric" style=background-color:white name="studid" class="inp" placeholder="Roll no" ><br>

        <label class="account" for="stname">Student Name:</label>
        <input type="text" style=background-color:white name="stname" class="inp" placeholder="Name" ><br><br>
        
        <input type="submit" name="submit" value="VIEW DETAILS" class="sub-btn"><br><br>
        <!--<div class="account">Don't have an Account?</div><br>-->

        <a href="nav.php" class="sub-btn">LOGOUT</a>
        </form>


        </div>
        </div>
        </body>
        </html>