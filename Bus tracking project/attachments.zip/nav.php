<html>

    <link href='style1.css' rel='stylesheet'>

<a href="index.php">
  <img id="adm" src="admin.png" alt="my picture" height="200" width="250" />
</a><br><br><br><br><br><br><br><br><br><br><br><br><br>
<a href="prlogin.php">
  <img id="adm" src="parent.png" alt="my picture" height="200" width="250" />
</a>

</html>