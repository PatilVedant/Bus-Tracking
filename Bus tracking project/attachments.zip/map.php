 <?php
    $latit1 = $_POST['num1'];
    $longit1 = $_POST['num2'];
    $latit2 = $_POST['num11'];
    $longit2 = $_POST['num21'];
?>
<html>
<head>
    <style type="text/css">
    html,
body,
#map-canvas {
  height: 100%;
  width: 100%;
  margin: 0px;
  padding: 0px
}
</style>
<script src="https://maps.googleapis.com/maps/api/js?key=&libraries=places"></script>
</head>
<body>

<div id="map-canvas"></div>
<button id="get">get direction </button>
</body>
<script>
   
var lat="<?php echo $latit1 ?>";
var lon="<?php echo $longit1 ?>";
var lat1="<?php echo $latit2 ?>";
var long1="<?php echo $longit2 ?>";

document.write(lat);
document.write(lon);

document.write(lat1);

document.write(long1);

    var queryString = decodeURIComponent(window.location.search);

    queryString = queryString.substring(1);
    // document.write("<br></br>")
    // document.write(queryString);
var queries = queryString.split("&");
//document.write(queries);
 // var latitude=queries[0].substring(6);
 // var longitude=queries[1].substring(6);

   var x1=parseFloat(lat);
         var y1=parseFloat(lon);

         var x2=parseFloat(lat1);
         var y2=parseFloat(long1);

var directionsDisplay=new google.maps.DirectionsRenderer();
var  directionsService = new google.maps.DirectionsService();
var map;
var baudha=new google.maps.LatLng(x1,y1);
var hattisar=new google.maps.LatLng(19.22056,73.093745);
var hattisar2=new google.maps.LatLng(18.989294,73.127162);

var mapOptions = {
                    zoom: 7,
                    center: baudha
                };

                                map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
                directionsDisplay.setMap(map);
               var marker = new google.maps.Marker({
         position: hattisar2,
         map: map,
         title: 'Hello World!'
        });


function calcRoute() {


var request={
    origin:baudha,
    destination:hattisar,
    travelMode:'DRIVING'
};

                directionsService.route(request, function (request, status) {
if(status== "OK")  {
    directionsDisplay.setDirections(request);
}              });
            }
            document.getElementById('get').onclick=function(){
                calcRoute();
            };


        
    </script>


</html>